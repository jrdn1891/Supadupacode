#import "RNSHeaderMenuToggleStateTracker.h"
#import <React/RCTAssert.h>

@implementation RNSHeaderMenuToggleStateTracker {
  NSMutableDictionary<NSString *, NSNumber *> *_states;
}

- (instancetype)init
{
  if (self = [super init]) {
    _states = [NSMutableDictionary new];
  }
  return self;
}

/**
 For singleSelection menus, only one item should have initialState set to true.
 This is enforced by JS-side and validated by an RCTAssert in RNSHeaderMenuCoordinator during menu build.
 */
- (BOOL)getToggleStateForItemWithId:(NSString *)menuItemId initialState:(BOOL)initialState
{
  NSNumber *existing = _states[menuItemId];
  if (existing != nil) {
    return existing.boolValue;
  }
  _states[menuItemId] = @(initialState);
  return initialState;
}

- (BOOL)toggleItemWithId:(NSString *)menuItemId
{
  NSNumber *existing = _states[menuItemId];
  BOOL newValue = !(existing != nil ? existing.boolValue : NO);
  _states[menuItemId] = @(newValue);
  return newValue;
}

- (void)selectItemWithId:(NSString *)menuItemId fromIds:(NSArray<NSString *> *)allItemIdsInMenu
{
  BOOL givenItemIsSelected = NO;
  for (NSString *itemId in allItemIdsInMenu) {
    if ([itemId isEqualToString:menuItemId]) {
      _states[itemId] = @YES;
      givenItemIsSelected = YES;
    } else {
      _states[itemId] = @NO;
    }
  }

  RCTAssert(
      givenItemIsSelected, @"[RNScreens] Attempt to select item \"%@\" that is not present in the list", menuItemId);
}

- (void)setToggleState:(BOOL)state forItemWithId:(NSString *)menuItemId
{
  _states[menuItemId] = @(state);
}

- (BOOL)toggleStateEquals:(BOOL)state forItemWithId:(nonnull NSString *)menuItemId
{
  if (_states[menuItemId] == nil) {
    return NO;
  }

  return [_states[menuItemId] boolValue] == state;
}

@end
